package com.example.test1.dao;

import java.util.HashMap;

import com.example.test1.model.Test;

public interface TestService {
	// 상품 불러오기
	HashMap<String, Object> testList(HashMap<String, Object> map);
	// 상품 삭제
	HashMap<String, Object> removeList(HashMap<String, Object> map);
	// 상품 수정
	HashMap<String, Object> updateList(HashMap<String, Object> map);
}
