package com.example.test1.mapper;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.example.test1.model.Test;

@Mapper
public interface TestMapper {
	// 상품 가져오기
	Test testList(HashMap<String, Object> map);
	// 상품 삭제
	void removeList(HashMap<String, Object> map);
	// 상품 수정
	void updateList(HashMap<String, Object> map);
}
