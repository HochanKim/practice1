package com.example.test1.dao;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.test1.mapper.TestMapper;
import com.example.test1.model.Test;

@Service
public class TestServiceImpl implements TestService{

	@Autowired
	TestMapper testMapper;

	@Override
	public HashMap<String, Object> testList(HashMap<String, Object> map) {
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		Test fruit = testMapper.testList(map);
		resultMap.put("fruit", fruit);
		System.out.println("불러올 상품번호 : "+map);
		return resultMap;
	}

	@Override
	public HashMap<String, Object> removeList(HashMap<String, Object> map) {
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		testMapper.removeList(map);
		System.out.println("삭제할 상품번호 : "+map);
		return resultMap;
	}

	@Override
	public HashMap<String, Object> updateList(HashMap<String, Object> map) {
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		testMapper.updateList(map);
		System.out.println("수정할 상품번호와 가격 : "+map);
		return resultMap;
	}

}
